#!/bin/bash

java -cp "dependency/*" com.force.aus.MetaDataExtractor 
